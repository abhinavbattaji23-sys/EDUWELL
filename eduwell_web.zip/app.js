(() => {
  // Simple SPA navigation
  const screens = document.querySelectorAll('.screen');
  const navBtns = document.querySelectorAll('.nav-btn');
  const navLinks = document.querySelectorAll('.nav-link');
  const backBtns = document.querySelectorAll('.back-btn');

  function showScreen(id) {
    screens.forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    navBtns.forEach(b => b.classList.toggle('active', b.id === 'btn-' + id));
    // reset quiz result if leaving quiz
    if (id !== 'quiz') resetQuizUI();
  }

  navBtns.forEach(b => b.addEventListener('click', () => {
    const id = b.id.replace('btn-','');
    showScreen(id);
  }));

  navLinks.forEach(l => l.addEventListener('click', (e) => {
    const target = e.currentTarget.dataset.target;
    showScreen(target);
  }));

  backBtns.forEach(b => b.addEventListener('click', (e) => {
    showScreen(e.currentTarget.dataset.target || 'home');
  }));

  // --- Quiz logic ---
  const questions = [
    {q: '2 + 2 = ?', options: ['3','4','5'], answer: '4'},
    {q: 'Water formula?', options: ['H2O','CO2','O2'], answer: 'H2O'},
    {q: 'Capital of India?', options: ['Delhi','Mumbai','Kolkata'], answer: 'Delhi'}
  ];
  let qIndex = 0, score = 0;

  const questionBox = document.getElementById('question-box');
  const optionsBox = document.getElementById('options-box');
  const resultBox = document.getElementById('result');

  function renderQuestion(){
    optionsBox.innerHTML = '';
    resultBox.classList.add('hidden');
    if(qIndex < questions.length){
      const q = questions[qIndex];
      questionBox.textContent = q.q;
      q.options.forEach(opt => {
        const btn = document.createElement('button');
        btn.className = 'option-btn';
        btn.textContent = opt;
        btn.addEventListener('click', () => handleAnswer(opt));
        optionsBox.appendChild(btn);
      });
    } else {
      finishQuiz();
    }
  }

  function handleAnswer(choice){
    if(choice === questions[qIndex].answer) score++;
    qIndex++;
    renderQuestion();
  }

  function finishQuiz(){
    questionBox.textContent = '';
    optionsBox.innerHTML = '';
    resultBox.classList.remove('hidden');
    resultBox.innerHTML = '<h3>Quiz Finished</h3><p>Your Score: ' + score + ' / ' + questions.length + '</p>';
    const restartBtn = document.createElement('button');
    restartBtn.className = 'nav-link';
    restartBtn.textContent = 'Back to Home';
    restartBtn.addEventListener('click', () => showScreen('home'));
    resultBox.appendChild(restartBtn);
  }

  function resetQuizUI(){
    qIndex = 0; score = 0;
    questionBox.textContent = '';
    optionsBox.innerHTML = '';
    resultBox.classList.add('hidden');
  }

  // initialize
  renderQuestion();
})();