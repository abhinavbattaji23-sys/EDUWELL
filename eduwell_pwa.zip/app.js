const screens = {
    home: `<h2>Welcome to EduWell!</h2>`,
    resources: `<h2>Study Resources</h2><ul><li>Math Notes</li><li>Science Videos</li><li>History PDFs</li></ul>`,
    health: `<h2>Mental Health Tips</h2><ul><li>Take breaks</li><li>Exercise</li><li>Talk to friends</li></ul>`,
    quiz: `<h2>Quiz</h2><p>2 + 2 = ?</p><button onclick='check("4")'>4</button> <button onclick='check("3")'>3</button><div id='result'></div>`
};
function showScreen(name) {
    document.getElementById('content').innerHTML = screens[name] || '';
}
function check(ans) {
    document.getElementById('result').innerText = ans === "4" ? "✅ Correct!" : "❌ Try again.";
}